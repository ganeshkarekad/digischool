import $ from 'jquery';
import moment from 'moment';
require('datatables.net');
require('moment-timezone');

var Calendar = require('tui-calendar'); /* CommonJS */
require("tui-calendar/dist/tui-calendar.css");

// If you use the default popups, use this.
require("tui-date-picker/dist/tui-date-picker.css");
require("tui-time-picker/dist/tui-time-picker.css");

$(document).ready(function()
{
    var $subjectContainer = $('.subjectPanel:last');
    var $removeSubjectBtn = '<a href="#" class="btn btn-sm btn-danger removeSubject">Remove</a>';

    $("#profilePic").change(function(){
        previewImage(this,'profileImage');
    });

    $('#addSubject').click(function(e){

        e.preventDefault();
        console.log($subjectContainer);
        $('.subjectPanel:last').after('<div class="subjectPanel col-4">'+$subjectContainer.html()+$removeSubjectBtn+'</div>');
    });

    $(document).on('click','.removeSubject', function(e)
    {
        e.preventDefault();
        $(this).parent().remove();
    });

    /**
     * Display the preview of selected images
     * 
     * input: input file
     * image: document ID of the <img> tag where the image will be previewed
     */
    function previewImage(input,image)
    {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
    
            reader.onload = function (e) {
                $('#'+image).attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }

    $('.add-class').on('click', function(e)
    {
      e.preventDefault();
      var $subject = $(this).parents('.timeSlot').find('select:last').parent();
      $(this).parents('.timeSlot').find('.subjectList:last').after('<div class="form-group subjectList">'+$($subject).html()+'</div>');
    });
    /**
     * Generate datatable along with basic search, sort & pagination functionalities
     */
    $('.generateTable').DataTable();
    
    // /**
    //  * Generate calendar
    //  */  
    // var calendar = new Calendar('#generateCalendar', {

    //     // 'day', 'week', 'month'
    //     defaultView: 'week',
    
    //     // shows the milestone and task in weekly, daily view
    //     taskView: true,
    
    //     // shows the all day and time grid in weekly, daily view
    //     scheduleView: true,
    
    //     // template options
    //     template: {
    //       milestone: function(schedule) {
    //         return '<span style="color:red;"><i class="fa fa-flag"></i> ' + schedule.title + '</span>';
    //       },
    //       milestoneTitle: function() {
    //         return 'Milestone';
    //       },
    //       task: function(schedule) {
    //         return '&nbsp;&nbsp;#' + schedule.title;
    //       },
    //       taskTitle: function() {
    //         return '<label><input type="checkbox" />Task</label>';
    //       },
    //       allday: function(schedule) {
    //         return schedule.title + ' <i class="fa fa-refresh"></i>';
    //       },
    //       alldayTitle: function() {
    //         return 'All Day';
    //       },
    //       time: function(schedule) {
    //         return schedule.title + ' <i class="fa fa-refresh"></i>' + schedule.start;
    //       }
    //     },
    //     week: {
    //       daynames: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    //       startDayOfWeek: 0,
    //       narrowWeekend: true
    //     },
    //     month: {
    //       daynames: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    //       startDayOfWeek: 0,
    //       narrowWeekend: true
    //     },
    
    //     // list of Calendars that can be used to add new schedule
    //     calendars: [],
    
    //     // whether use default creation popup or not
    //     useCreationPopup: false,
    
    //     // whether use default detail popup or not
    //     useDetailPopup: false
        
    // });

    // calendar.createSchedules([
    //     {
    //         id: '1',
    //         calendarId: '1',
    //         title: 'English Class',
    //         category: 'time',
    //         start: moment('2019-12-13 09:00:00').tz("India/Kolkata").format('YYYY-MM-DD LT'),
    //         end: moment('2019-12-13 11:00:00').tz("India/Kolkata").format('YYYY-MM-DD LT')
    //     },
    //     {
    //         id: '2',
    //         calendarId: '1',
    //         title: 'second schedule',
    //         category: 'time',
    //         dueDateClass: '',
    //         start: '2018-01-18T17:30:00+09:00',
    //         end: '2018-01-19T17:31:00+09:00',
    //         isReadOnly: true    // schedule is read-only
    //     }
    // ]);
});