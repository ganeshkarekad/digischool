require('jquery');
require('popper.js');
require('./bootstrap');
require('perfect-scrollbar');
require('@coreui/coreui');
require('chart.js');
require('./custom');