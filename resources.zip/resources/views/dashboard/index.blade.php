@extends('layouts.app')
@section('content')
<div class="c-body">
    <main class="c-main">
        <div class="container-fluid">
            <div class="fade-in">
                <div class="row">
                    
                </div>
            </div>
        </div>
    </main>
</div>
 @endsection