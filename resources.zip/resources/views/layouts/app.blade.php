<!DOCTYPE html>
<html lang="en">
  <head>
    <base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="description" content="CoreUI - Laravel">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>CoreUI Integration with Laravel</title>

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" />
    <script href="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script href="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>

  </head>
  <body class="c-app">
    @if(Auth::user())
      @include('common.header')
    @endif
    <div class="c-body">
        <main class="c-main">
          <div class="container-fluid">
            <div class="fade-in">
              <div class="row">
                @yield('content')
              </div>
            </div>
          </div>
        </main>
      </div>
    @include('common.footer')

     <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
    
    <!-- Include the script only on homepage -->
  </body>
</html>