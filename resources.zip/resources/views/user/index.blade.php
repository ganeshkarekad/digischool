@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">{{ $page['title']?$page['title']:'User' }}</div>
                    <div class="card-body">
                        <div class="container">
                            <table class="table table-responsive-sm table-hover table-outline mb-0 generateTable" >
                            <thead class="thead-light">
                                <tr>
                                <th class="text-center">
                                    <svg class="c-icon">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-people"></use>
                                    </svg>
                                </th>
                                <th>User</th>
                                <th class="text-center">Role</th>
                                <th class="text-center">Organisation</th>
                                <th class="text-center">Course</th>
                                <th>Activity</th>
                                </tr>
                            </thead>
                            <tbody>
                            @foreach($users as $user)
                            <tr>
                                <td class="text-center">
                                    <div class="c-avatar"><img class="c-avatar-img" style="height:36px;width:36px;" src="{{ $user->avatar() }}" alt="{{ $user->email }}"></div>
                                </td>
                                <td>
                                    <div>{{ $user->firstName.' '.$user->lastName }}</div>
                                    <div class="small text-muted">Registered: {{ $user->created_at }}</div>
                                </td>
                                <td class="text-center">
                                    {{ $user->roles()->first()->name }}
                                </td>
                                <td class="text-center">
                                    @if($user->organisation != null)
                                        {{ $user->organisation->name }}
                                    @else
                                        Not Assigned    
                                    @endif
                                </td>
                                <td>
                                    @if($user->course != null)
                                        {{ $user->course->name }}
                                    @else
                                        Not Assigned
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('userUpdate',['id' => $user->id]) }}" class="btn btn-sm btn-info">Edit</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
        </div>
    <!-- /.col-->
</div>
@endsection