@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">User Edit</div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('userStore') }}" enctype="multipart/form-data">
                            @csrf
                            <div class="form-group justify-content-center text-center">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="container" style="padding-bottom:10px;">
                                            <img src="{{ $user->avatar() }}" style="width:150px;height:150px;" class="rounded-circle img-fluid" id="profileImage">
                                        </div>
                                        <input type="file" name="profilePic" id="profilePic" class="form-control @error('profilePic') is-invalid @enderror">
                                        @error('profilePic')
                                            <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                        @endif
                                    </div>
                                    <div class="col-6 text-left">
                                        <div class="form-group">
                                            <label for="userRoles">Role</label>
                                            <select name="roles" class="form-control @error('roles') is-invalid @enderror">
                                                @foreach($roles as $role)
                                                    @if($role->id > Auth::user()->roles()->first()->id)
                                                        @if(($user->id != null && in_array($role,$userRoles)) || ($role->id == old('roles')) || (isset($defaultRole) && $defaultRole == $role->id) )
                                                            <option value="{{ $role->id }}" selected>{{ $role->name }}</option>
                                                        @else
                                                            <option value="{{ $role->id }}">{{ $role->name }}</option>
                                                        @endif
                                                    @endif
                                                @endforeach
                                            </select>
                                        </div>
                                        @if(isset($courses))
                                        <div class="form-group">
                                            <label for="course">Course</label>
                                            <select class="form-control" name="course">
                                                <option value="">--SELECT--</option>
                                                @foreach($courses as $course)
                                                    <option value="{{ $course->id }}">{{ $course->name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" name="id" value="@if($user->id != null){{ $user->id }}@endif">
                            <div class="form-group row">
                                <div class="col-6">
                                    <label for="firstName">First Name</label>
                                    <input class="form-control @error('firstName') is-invalid @enderror" id="firtName" name="firstName" type="text" placeholder="Enter your first name" value="@if($user->id != null && !old('firstName')) {{ $user->firstName }} @else {{ old('firstName') }}@endif">
                                    @error('firstName')
                                        <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                    @endif
                                </div>
                                <div class="col-6">
                                    <label for="lastName">Last Name</label>
                                    <input class="form-control  @error('lastName') is-invalid @enderror" id="lastName" name="lastName" type="text" placeholder="Enter your last name" value="@if($user->id != null && !old('lastName')) {{ $user->lastName }} @else {{ old('lastName') }}@endif">
                                    @error('lastName')
                                        <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                    @endif
                                </div>

                            </div>
                            <div class="form-group">
                                <label for="dateOfBirth">E-mail</label>
                                <input class="form-control  @error('email') is-invalid @enderror"" id="email" name="email" type="text" placeholder="Type your e-mail address"  value="@if($user->id != null && !old('email')) {{ $user->email }} @else {{ old('email') }}@endif">
                                @error('email')
                                    <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control  @error('password') is-invalid @enderror" id="password" name="password" placeholder="Type your password" />
                            </div>
                            <div class="form-group">
                                <label for="dateOfBirth">Date Of Birth</label>
                                <input class="form-control  @error('dateOfBirth') is-invalid @enderror" id="dateOfBirth" name="dateOfBirth" type="text" placeholder="DD-MM-YYYY"  value="@if($user->id != null && !old('dateOfBirth')) {{ $user->dateOfBirth }} @else {{ old('dateOfBirth') }}@endif">
                                @error('dateOfBirth')
                                    <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                @endif
                            </div>
                            <div class="form-group">
                                <label for="street">Street</label>
                                <input class="form-control  @error('street') is-invalid @enderror" id="street" type="text" name="street" placeholder="Enter street name"  value="@if($user->id != null && !old('street')) {{ $user->street }} @else {{ old('street') }}@endif">
                                @error('street')
                                    <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                @endif
                            </div>
                            <div class="row">
                            <div class="form-group col-sm-8">
                                <label for="city">City</label>
                                <input class="form-control  @error('city') is-invalid @enderror" id="city" type="text" name="city" placeholder="Enter your city" value="@if($user->id != null && !old('city')) {{ $user->city }} @else {{ old('city') }}@endif">
                                @error('city')
                                    <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                @endif
                            </div>
                            <div class="form-group col-sm-4">
                                <label for="postal-code">Postal Code</label>
                                <input class="form-control  @error('postalCode') is-invalid @enderror" id="postalCode" name="postalCode" type="text" placeholder="Postal Code" value="@if($user->id != null && !old('pinCode')) {{ $user->pinCode }} @else {{ old('pinCode') }}@endif">
                                @error('postalCode')
                                    <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                @endif
                            </div>
                            </div>

                            <div class="form-group">
                                <label for="country">Country</label>
                                <input class="form-control  @error('country') is-invalid @enderror" id="country" type="text" name="country" placeholder="Country name" value="@if($user->id != null && !old('country')) {{ $user->country }} @else {{ old('country') }}@endif">
                                @error('country')
                                    <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                @endif
                            </div>

                            <div class="form-group">
                                <input type="submit" class="btn btn-success btn-md float-right" value="@if($user->id == null) Add @else Update @endif" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection                    