@extends('layouts.app')

@section('content')
<form method="POST" class="form-horizontal" style="width:100%;" method="POST">
    @csrf
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Timetable for {{ $course->name }}</div>
                        <div class="card-body">
                            <div class="row">
                                @foreach($days as $key=>$day)
                                    <div class="col-6">
                                        <div class="card">
                                            <div class="card-header">{{ $day }}</div>
                                            <div class="card-body">
                                                <div class="timeSlot">
                                                    <input type="hidden" name="day[]" value="{{ $key }}">   
                                                    <div class="form-group subjectList">
                                                        <select name="subject[{{$key}}][]" class="form-control">
                                                            <option value="">-- SELECT --</option>
                                                            @foreach($subjects as $key=>$subject)
                                                                <option value="{{ $key }}">{{ $subject }}</option>
                                                            @endforeach
                                                            <option value="LB">Lunch Break</option>
                                                            <option value="RB">Recreational Break</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <a href="#" class="btn btn-sm btn-info add-class">Add another class</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-md btn-primary float-right">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</form>
@endsection
