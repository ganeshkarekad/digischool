@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Organisation</div>
                    <div class="card-body">
                        <form method="POST" action="{{ route('organisationStore') }}" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="id" value="{{ $organisation->id }}">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="form-group">
                                        <label for="name">Organisation Name</label> 
                                            <input type="text" placeholder="Type the name of the organisation" name="name" id="name" class="form-control @error('name') is-invalid @enderror" value="@if($organisation->id != null && !old('name')) {{ $organisation->name }} @else {{ old('name') }}@endif">
                                            @error('profilePic')
                                                <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                            @endif
                                        </div>
                                        <div class="form-group">
                                        <label for="shortDescription">Slogan</label>
                                            <input type="text" name="shortDescription" id="shortDescription" class="form-control @error('shortDescription') is-invalid @enderror" value="@if($organisation->id != null && !old('organisation')) {{ $organisation->shortDescription }} @else {{ old('shortDescription') }}@endif"/>
                                            @error('shortDescription')
                                                <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                            @endif
                                        </div>
                                        <div class="form-group">
                                            <label for="user">Assign Administrator</label> 
                                            <select name="user" class="form-control">
                                                <option>--SELECT--</option>
                                                @foreach($users as $user)
                                                    @if($user->organisationId == $organisation->id)
                                                        <option value="{{ $user->id }}" selected>{{ $user->firstName.' '.$user->lastName }}</option>
                                                    @else
                                                        <option value="{{ $user->id }}">{{ $user->firstName.' '.$user->lastName }}</option>
                                                    @endif
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <img src="{{ $organisation->avatar() }}" style="height:200px;width:100%;" id="profileImage"/>
                                        <input type="file" name="logo" id="profilePic" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="description">About the Organisation</label>
                                    <textarea type="text" name="description" id="description" class="form-control @error('description') is-invalid @enderror" rows="10" cols="20">
                                        @if($organisation->id != null && !old('description')) {{ $organisation->description }} @else {{ old('description') }}@endif
                                    </textarea>
                                    @error('description')
                                        <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                    @endif
                                </div>
                                <div class="container">
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="configurationValue">Opening Time</label>
                                                <input type="time" name="_OPENING_TIME_" id="_OPENING_TIME_" class="form-control @error('_OPENING_TIME_') is-invalid @enderror" value="@if(isset($config['_OPENING_TIME_'])){{ date('H:i',strtotime($config['_OPENING_TIME_'])) }}@else{{ old('_OPENING_TIME_') }}@endif">
                                                @error('_OPENING_TIME_')
                                                    <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-4 form-group">
                                            <label for="configurationValue">Closing Time</label>
                                            <input type="time" name="_CLOSING_TIME_" id="_CLOSING_TIME_" class="form-control @error('_CLOSING_TIME_') is-invalid @enderror" value="@if(isset($config['_CLOSING_TIME_'])){{ date('H:i',strtotime($config['_CLOSING_TIME_'])) }}@else{{ old('_CLOSING_TIME_') }}@endif">
                                            @error('_CLOSING_TIME_')
                                                <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                            @endif
                                        </div>
                                        <div class="col-4 form-group">
                                            <label for="configurationValue">Class Durations(in minutes)</label>
                                            <input type="number" name="_CLASS_DURATION_" id="_CLASS_DURATION_" class="form-control @error('_CLASS_DURATION_') is-invalid @enderror" value="@if(isset($config['_CLASS_DURATION_'])){{$config['_CLASS_DURATION_']}}@else{{ old('_CLASS_DURATION_')}}@endif">
                                            @error('_CLASS_DURATION_')
                                                <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                            @endif
                                        </div>
                                        <div class="col-4 form-group">
                                            <label for="configurationValue">Lunch Break Starts From</label>
                                            <input type="time" name="_LUNCH_BREAK_START_TIME_" id="_LUNCH_BREAK_START_TIME_" class="form-control @error('_LUNCH_BREAK_START_TIME_') is-invalid @enderror" value="@if(isset($config['_LUNCH_BREAK_START_TIME_'])){{ date('H:i',strtotime($config['_LUNCH_BREAK_START_TIME_'])) }}@else{{ old('_LUNCH_BREAK_START_TIME_') }}@endif">
                                            @error('_LUNCH_BREAK_START_TIME_')
                                                <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                            @endif
                                        </div>
                                        <div class="col-4 form-group">
                                            <label for="configurationValue">Lunch Break Ends At</label>
                                            <input type="time" name="_LUNCH_BREAK_END_TIME_" id="_LUNCH_BREAK_END_TIME_" class="form-control @error('_LUNCH_BREAK_END_TIME_') is-invalid @enderror" value="@if(isset($config['_LUNCH_BREAK_END_TIME_'])){{ date('H:i',strtotime($config['_LUNCH_BREAK_END_TIME_'])) }}@else{{ old('_LUNCH_BREAK_END_TIME_') }}@endif">
                                            @error('_LUNCH_BREAK_END_TIME_')
                                                <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                            @endif
                                        </div>
                                        <div class="col-4 form-group">
                                            <label for="configurationValue">Recreational break(s) Duration(In Minutes)</label>
                                            <input type="number" name="_BREAK_DURATION_" id="_BREAK_DURATION_" class="form-control @error('_BREAK_DURATION_') is-invalid @enderror" value="@if(isset($config['_BREAK_DURATION_'])){{ $config['_BREAK_DURATION_'] }}@else{{ old('_BREAK_DURATION_') }}@endif">
                                            @error('_BREAK_DURATION_')
                                                <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                            @endif
                                        </div>
                                        <div class="col-4 form-group">
                                            <label for="configurationValue">Number of breaks per day</label>
                                            <input type="number" name="_NUMBER_OF_BREAK_" id="_NUMBER_OF_BREAK_" class="form-control @error('_NUMBER_OF_BREAK_') is-invalid @enderror" value="@if(isset($config['_NUMBER_OF_BREAK_'])){{$config['_NUMBER_OF_BREAK_']}}@else{{ old('_NUMBER_OF_BREAK_')}}@endif">
                                            @error('_NUMBER_OF_BREAK_')
                                                <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                            @endif
                                        </div>
                                    </div>
                                </div>


                            <div class="form-group">
                                <input type="submit" class="btn btn-md btn-success float-right" value="@if($organisation->id == '')Add @else Update @endif "/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection