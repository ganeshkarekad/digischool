@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Users</div>
                    <div class="card-body">
                        <div class="container">
                            <table class="table table-responsive-sm table-hover table-outline mb-0 generateTable">
                            <thead class="thead-light">
                                <tr>
                                <th class="text-center">
                                    <svg class="c-icon">
                                    <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-people"></use>
                                    </svg>
                                </th>
                                <th>Organisation</th>
                                <th>Slogan</th>
                                <th class="text-center">Number of people</th>
                                <th>Activity</th>
                                </tr>
                            </thead>
                            <tbody>
                            @foreach($organisations as $organisation)
                            <tr>
                                <td class="text-center">
                                    <div class="c-avatar"><img class="rounded" style="height:36px;width:36px;" src="{{ $organisation->avatar() }}" alt="{{ $organisation->name }}"></div>
                                </td>
                                <td>
                                    <div>{{ $organisation->name }}</div>
                                    <div class="small text-muted">Registered: {{ $organisation->created_at }}</div>
                                </td>
                                <td class="text-center">
                                    {{ $organisation->shortDescription }}
                                </td>
                                <td class="text-center">
                                    {{ count($organisation->users) }}
                                </td>
                                <td>
                                    <a href="{{ route('organisationUpdate',['id' => $organisation->id]) }}" class="btn btn-sm btn-info">Edit</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
        </div>
    <!-- /.col-->
</div>
@endsection