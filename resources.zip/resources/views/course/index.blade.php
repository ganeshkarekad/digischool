@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Courses</div>
                    <div class="card-body">
                        <div class="container">
                            <table class="table table-responsive-sm table-hover table-outline mb-0 generateTable">
                            <thead class="thead-light">
                                <tr>
                                <th>Course</th>
                                <th>Description</th>
                                <th>Number of people enrolled</th>
                                <th>Number of Subjects</th>
                                <th></th>
                                </tr>
                            </thead>
                            <tbody>
                            @foreach($courses as $course)
                            <tr>
                                <td>
                                    <div>{{ $course->name }}</div>
                                    <div class="small text-muted">Registered: {{ $course->created_at }}</div>
                                </td>
                                <td class="text-center">
                                    {{ $course->description }}
                                </td>
                                <td class="text-center">
                                    {{ count($course->users) }}
                                </td>
                                <td>
                                    {{ count($course->subjects) }}
                                </td>
                                <td>
                                    <a href="{{ route('timetableMain',['id' => $course->id]) }}" class="btn btn-sm btn-warning">Set Timetable</a>
                                    <a href="{{ route('courseUpdate',['id' => $course->id]) }}" class="btn btn-sm btn-info">Edit</a>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
        </div>
    <!-- /.col-->
</div>
@endsection