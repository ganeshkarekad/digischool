@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Course</div>
                    <div class="card-body">
                        <form class="form-horizontal" action="{{ route('courseStore') }}" method="POST">
                            @csrf
                            <input type="hidden" name="id" value="{{ $course->id }}">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label for="name">Course Name</label>
                                        <input type="text" name="name" id="name" class="form-control @error('name') is-invalid @enderror" value="@if($course->id != null && !old('name')) {{ $course->name }} @else {{ old('name') }}@endif">
                                        @error('name')
                                            <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="name">Course Description</label>
                                        <input type="text" name="description" id="description" class="form-control @error('description') is-invalid @enderror" value="@if($course->id != null && !old('description')) {{ $course->description }} @else {{ old('description') }}@endif">
                                        @error('description')
                                            <span class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong></span>
                                        @endif
                                    </div>
                                    <div class="form-group">
                                        <label for="staff">Staff In Charge</label>
                                        <select name="staff" class="form-control">
                                            <option value="">--SELECT--</option>
                                            @foreach($staffs as $staff)
                                                @if($staff->id == $course->staffInCharge)
                                                    <option value="{{ $staff->id }}" selected>{{ $staff->firstName.' '.$staff->lastName }}</option>
                                                @else   
                                                    <option value="{{ $staff->id }}">{{ $staff->firstName.' '.$staff->lastName }}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="alert alert-info">
                                        Add the subjects pertaining to this course. You can edit this after creation OR add after the creation of the course too!
                                    </div>
                                    <div class="row">
                                        @if(isset($subjects))
                                            @foreach($subjects as $key => $subject)
                                                <div class="subjectPanel col-4">
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="form-group">
                                                                <label for="subjectName">Subject Name</label>
                                                                <input type="text" name="subjectName[]" class="form-control" placeholder="Enter the Subject Name" value="{{ $subject->name }}">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="subjectDescription">Subject Description</label>
                                                                <input type="text" name="subjectDescription[]" class="form-control" placeholder="Enter the Subject Description" value="{{ $subject->description }}">
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="staffId">Staff In Charge</label>
                                                                <select class="form-control" name="staffId[]">
                                                                    <option value="">--SELECT--</option>
                                                                    @foreach($staffs as $staff)
                                                                        @if($staff->id == $subject->staffId)
                                                                            <option value="{{ $staff->id }}" selected>{{ $staff->firstName.' '.$staff->lastName }}</option>
                                                                        @else
                                                                            <option value="{{ $staff->id }}">{{ $staff->firstName.' '.$staff->lastName }}</option>
                                                                        @endif
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                            <a href="#" class="btn btn-sm btn-danger removeSubject">Remove</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @endif
                                        <div class="subjectPanel col-4">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="form-group">
                                                        <label for="subjectName">Subject Name</label>
                                                        <input type="text" name="subjectName[]" class="form-control" placeholder="Enter the Subject Name">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="subjectDescription">Subject Description</label>
                                                        <input type="text" name="subjectDescription[]" class="form-control" placeholder="Enter the Subject Description">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="staffId">Staff In Charge</label>
                                                        <select class="form-control" name="staffId[]">
                                                            <option value="">--SELECT--</option>
                                                            @foreach($staffs as $staff)
                                                                <option value="{{ $staff->id }}">{{ $staff->firstName.' '.$staff->lastName }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <a href="#" class="btn btn-primary float-right" id="addSubject">Add Subject</a>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="submit" value="@if($course->id == null) Add @else Update @endif Course" class="btn btn-md btn-success">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
